package com.example.jake.w4_p4;

public interface HangmanListener {
    public void setUpNewGame();
    public void processGuess(char letter);
}
